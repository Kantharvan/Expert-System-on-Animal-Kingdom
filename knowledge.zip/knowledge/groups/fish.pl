:- dynamic(fish/1).
fish(shark).
