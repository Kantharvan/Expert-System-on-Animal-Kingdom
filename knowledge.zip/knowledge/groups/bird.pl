:- dynamic(bird/1).
bird(parrot).
