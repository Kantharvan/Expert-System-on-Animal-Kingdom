:- dynamic(pet/1).
pet(cat).

pet(dog).

pet(parrot).
pet(hamster).

pet(hamster).

pet(fish).

pet(cow).
