:- dynamic(marsupial/1).
marsupial(kangaroo).
