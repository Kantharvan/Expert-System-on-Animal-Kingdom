:- dynamic(feline/1).
feline(pumas).

feline(cat).
