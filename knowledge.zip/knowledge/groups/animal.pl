:- dynamic(animal/1).
animal(pigeon).
