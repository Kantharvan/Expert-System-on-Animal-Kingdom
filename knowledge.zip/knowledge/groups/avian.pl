:- dynamic(avian/1).
avian(crow).
