:- dynamic(amphibian/1).
amphibian(frog).
