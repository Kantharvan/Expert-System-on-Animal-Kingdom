
canine(dog).
