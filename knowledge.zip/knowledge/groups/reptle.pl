:- dynamic(reptle/1).
reptle(py).
